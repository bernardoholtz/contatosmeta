
var contatos ="";
var retorno;
var app = angular.module('contatosApp',[]);




app.controller('CtrlContatos',function($scope,$http){
	var pages =[];
	var tams = [];
	for (i=0;i <99; i++){
		pages.push(i)
		tams.push(i);
	}
	    
	$scope.pages = pages;
	$scope.tams= tams;
	
	$scope.carregar = function() {
		
		var pagina = parseInt(($('#Pagina').val() == "") ? 0 : $('#Pagina').val());
		var tam = parseInt(($('#Tamanho').val() == "") ? 10 : $('#Tamanho').val());
	
		 var filtro = [pagina,tam];
		 $http({
			  method: 'POST',
			  url: '/api/contato',
			  data: filtro
		   }).then(function (data){
			     $scope.contatos = data.data;
			     contatos = data.data;
			   
		   },function (error){
			//alert('Error: ' + data);
		   });
        
    
   };
	
	$scope.novo = function() {
		$('#painelContato').css('display','block');
		$('#painelConsulta').css('display','none');
		$('#Id').val("");
		$('#Nome').val("");
		$('#Descricao').val("");
		$('#Tipo').val("");
		$('#Valor').val("");
		$('#Obs').val("");
		
	};
	
	$scope.voltar = function() {
		$('#painelContato').css('display','none');
		$('#painelConsulta').css('display','block');
		$scope.carregar();
	};
	

	
	$scope.excluir = function(id) {
		
		var filtro = [id];
		var r = confirm("Deseja mesmo excluir esse contato?");
		if (r == true) {
			$http({
				  method: 'POST',
				  url: '/api/exclusao',
				  data: filtro
			   }).then(function (data){
					alert(data.data);
					$scope.voltar();
			   },function (error){
				alert('Error: ' + error);
			   });	
		}
        
   };	
	
	$scope.transpor = function(id,nome,descricao,tipo,valor,obs) {
		var txt;
		$('#painelContato').css('display','block');
		$('#painelConsulta').css('display','none');
		$('#Id').val(id);
		$('#Nome').val(nome);
		$('#Descricao').val(descricao);
		$('#Tipo').val(tipo);
		$('#Valor').val(valor);
		$('#Obs').val(obs);
   };	
	
	
    $scope.enviar = function() {
		
		var id = $('#Id').val();
		var nome = $('#Nome').val();
		var descricao = $('#Descricao').val();
		var canal =$('#Tipo').val();
		var valor = $('#Valor').val();;
		var obs=$('#Obs').val();;
		var filtro = [id,nome,descricao,canal,valor,obs];
		if (id == ""){
			$http({
			  method: 'POST',
			  url: '/api/envio',
			  data: filtro
		   }).then(function (data){
				alert(data.data);
				$scope.voltar();
		   },function (error){
			alert('Error: ' + error);
		   });
		}else{
			$http({
			  method: 'POST',
			  url: '/api/edicao',
			  data: filtro
		   }).then(function (data){
				alert(data.data);
				$scope.voltar();
		   },function (error){
			alert('Error: ' + error);
		   });
		}
		
    
    
   };	
	
	

 
 
}); 

