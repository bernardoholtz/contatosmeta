var mongoose = require ('mongoose');
mongoose.connect('mongodb://localhost/empresa');
var Schema = new mongoose.Schema({
	_id: String,
	name: String,
	age: Number
});

var user = mongoose.model('emp',Schema);

new user({
	_id: '35',
	name:'bernardo',
	age: 35
}).save(function(err,doc){
	if (err) console.log(err);
	else 
	console.log('gravado com sucesso');
});