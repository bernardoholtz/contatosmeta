var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

//var user = mongoose.model('contatos',Schema);

module.exports = function (app) {


	
    app.post('/api/contato', function (req, res) {
		MongoClient.connect(url, function(err, db) {
			  if (err) throw err;
			  var dbo = db.db("contatosdb");
			console.log(req.body[0]);
			console.log(req.body[1]);
			  dbo.collection("contatos").find().skip(req.body[0]).limit(req.body[1]).toArray(function(err, result) {
					if (err) throw err;
					//console.log(JSON.stringify(result)); 
					res.send(JSON.stringify(result));
					res.end();
					db.close();
			  });
		 }); 
					
	
	});
	
	
	
	app.post('/api/envio', function (req, res) {
		 MongoClient.connect(url, function(err, db) {
			  if (err) throw err;
			  var dbo = db.db("contatosdb");
			  var myobj = [
				{ 
					nome:req.body[1],
					descricao: req.body[2],
					canal: req.body[3],
					valor: req.body[4],
					obs: req.body[5]
				}
			  ];
			  dbo.collection("contatos").insertMany(myobj, function(err, result) {
				if (err) throw err;
				db.close();
				res.send("Contato inserido com sucesso");
				res.end();
			  });
			}); 
		
    });
	
	app.post('/api/edicao', function (req, res) {
		var mongodb = require('mongodb');
		 MongoClient.connect(url, function(err, db) {
			  if (err) throw err;
			  var dbo = db.db("contatosdb");
			  var myquery = { _id:new mongodb.ObjectID(req.body[0])};
			 //var newvalues = { $set: {name: "Mickey", address: "Canyon 123" } };
			   var myobj = 	{ $set:
				{
					nome:req.body[1],
					descricao: req.body[2],
					canal: req.body[3],
					valor: req.body[4],
					obs: req.body[5]
				}
			   };
			  dbo.collection("contatos").update(myquery, myobj, function(err, result) {
				if (err) throw err;
				db.close();
				res.send("Contato atualizado com sucesso");
				res.end();
			  });
			}); 
		
    });
	
	app.post('/api/exclusao', function (req, res) {
		   var mongodb = require('mongodb');
			MongoClient.connect(url, function(err, db) {
			  if (err) throw err;
			  var dbo = db.db("contatosdb");
			 console.log(req.body[0]);
			  var myquery = { _id:new mongodb.ObjectID(req.body[0])};
				//var myquery = { canal: 'Email'};
			  dbo.collection("contatos").remove(myquery, function(err, obj) {
				if (err) throw err;
				db.close();
				res.send("Contato excluído com sucesso");
				res.end();
			  });
			}); 
			
    });

	//fazendo a conexão global


    app.get('*', function (req, res) {
        res.sendFile(__dirname + '/public/index.html'); 
    });
};
